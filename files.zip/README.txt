========================================
AROMATIC PLANT DASHBOARD
========================================

HOW TO USE:
-----------

1. FIRST TIME SETUP:
   - You'll have 2 files in this folder:
     * AromaticPlant_Dashboard.html (the actual dashboard)
     * Open_Dashboard.vbs (the launcher)
   
   - Make sure Google Chrome is installed on your computer

2. TO OPEN THE DASHBOARD:
   - Double-click "Open_Dashboard.vbs"
   - Chrome will open with the dashboard
   
3. USING THE DASHBOARD:
   - Change Process Areas (Preparation, Aromizer, Recovery)
   - Enter Lab values (Conversion %, Paraxylene, Benzene, LPG, ED OH)
   - Auto-generated script updates automatically
   - Select voice: AI Voice or record your own
   - Click "SPEAK MY INTRO" to present
   
4. DATA SAVING:
   - Everything saves automatically in your browser
   - You'll see "Saving..." then green "Saved"
   - Close and reopen - all your data is preserved
   - Works completely offline

5. SHARING:
   - Send both files together
   - Each person keeps their own data in their browser

========================================
Questions? The dashboard is self-explanatory!
========================================
